<?php
session_start();
/*
File: masuk.php
Fungsi: Form untuk login.
Auth: ShowCheap
*/
if(file_exists("upgrade/index.php")){
    header('location: upgrade/index.php');
    exit(0);
}
require 'sistem/config.php';
$pencet=$_POST['tmbl'];
sambung();
if(isset($_SESSION['level'])){
   $sesi=$_SESSION['level'];    
    if(($sesi=='Admin' || $sesi=='Pustakawan')){
        header('location: welcome_admin.php');
    }
}
$nama=mysql_real_escape_string($_POST['nama']);
$kunci=md5($_POST['kunci']);

?>
<html>
<head>
<!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="shortcut icon" href="logo.png">
      <title>Telkom CorpU Prakerin</title>

    <script type="text/javascript" ></script>
    <style type="text/css">
      body {
        background-color:black;
        background-image:url(img/a.jpg);
        background-size: cover;
        background-repeat: no-repeat;
      }
    </style>
</head>    
<body>

<?php
if ($pencet != '' && $nama != '' && $kunci != ''){
    $s=mysql_query("SELECT * FROM tbl_pustakawan WHERE user='".$nama."' AND kunci='".$kunci."'");
    $c=mysql_num_rows($s);
    if($c == '1'){
      $t= mysql_fetch_array($s);
      $log=$t['login'];
      $log=$log+1;
      mysql_query("UPDATE tbl_pustakawan SET login='$log' WHERE user='$nama'");
      $_SESSION['nama']=$t['nama'];
      $_SESSION['level']=$t['level'];
      $_SESSION['uid']=$t['id'];
      catat($_SESSION['nama'],"Berhasil Login");
      //header('location: index.php');
      echo "<script>window.location='welcome_admin.php'</script>";
      exit();
    }else{
        catat($nama,"Gagal Login");
        $script= "<script type='text/javascript'>";
        $script.="$('document').ready(function(){";
        $script.="$('#result').html('<p class=\'alert alert-error\'>Username dan Password tidak cocok !</p>');";
        $script.="})";
        $script.="</script>";
        echo $script;
    }
};
?>

  <div class="container">
    <form action="" method="post">
    <div class="row no-gutter">
          <div class=" d-md-flex col-md-4 col-lg-6 bg-image"></div>
          <div class="col-md-8 col-lg-6">
            <div class="login d-flex align-items-center py-5">
              <div class="container" id="log">
                <div class="row">
                  <div class="col-md-9 col-md-8 mx-auto" id="col1">
                    <br>
                    <a href="index.php">
                    <img src="logo.png" width="70" height="70"style="float:right" />
                    </a>
                    <br>
                    <h2 class="login-heading text-dark">MASUK</h2>
                    <br>
                    <h5>Silahkan Isi Terlebih dahulu<h5>
                       <div class="form-label-group">
                        <label for="inputUsername"></label>
                        <input name="nama"type="text" id="username" class="form-control" placeholder="Username" required autofocus>
                      </div>

                      <div class="form-label-group" style="padding-top: 7px">
                        <label for="inputPassword"></label>
                        <input name="kunci"type="password" id="Password" class="form-control" placeholder="Password" required>
                      </div>

                      <div class="custom-control custom-checkbox mb-3" style="padding-top: 7px">
                        <input type="checkbox" class="custom-control-input" id="customCheck1">
                        <label class="custom-control-label small text-dark" for="customCheck1">Simpan Password</label>
                      </div>
                      <br>
                      <button class="btn btn-md btn-danger btn-block btn-login text-uppercase font-weight-bold mb-2 text-light" type='submit' value='LOGIN' name='tmbl' id="login">Masuk</button>
                      <div class="text-center">
                        <a class="small text-danger" href="daftar.php">Belum Punya Akun??</a>
                      </div>
                  </div>
                </div>
              </div>
            </div>
          </div>        
    </div>
  </form>
</div> 

</body>    
</html>


