
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="shortcut icon" href="img/logo.png">
    <title>Telkom CorpU Prakerin</title>
  </head>


  <body>
    <nav class="navbar text-light navbar-expand-lg navbar-dark bg-dark fixed-top" style="background-color: #;">
    <div class="container">
      <a class="navbar-brand">
        <img src="img/logo.png" width="40" height="40" class="d-inline-block align-top" alt="img/logo.png"> Telkom CorpU Prakerin
      </a>    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">Beranda
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#tentangkami-section">Tentang Kami</a>
                <span class="sr-only">(current)</span>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Info</a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <a class="dropdown-item" href="siswa.php">Siswa Prakerin</a>
                  <a class="dropdown-item" href="pembimbing.php">Pembimbing Siswa Prakerin</a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="#">Lainnya</a>
              </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#galeri-section">Galeri</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#kegiatan-section">Kegiatan</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#kontak-section">Kontak</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle fas fa-search" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown"> 
                  <input type="text" class="form-control" name="query" placeholder="Kata Kunci" aria-label="search" style="width: 100px; float: left; border-radius:3px 0px 0px 3px;" >
                    <button class="btn btn-success" type="submit" data-toggle="tooltip" data-placement="top" title="Belum bisa Digunakan" style=" border-radius: 0px 3px 3px 0px;">Cari</button>
                  
              </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle fas fa-user" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class=""></a>
                <a class="dropdown-item" href="keluar.php" title='Keluar Aplikasi'>Keluar</a>
              </div>
          </li>
        </ul>
      </div>
    </div>
    </nav>

    <div class="bd-example">
      <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
          <ol class="carousel-indicators">
            <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
            <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
            <li data-target="#carouselExampleCaptions" data-slide-to="3"></li>
          </ol>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="img/d.jpg" class="d-block w-100" alt="img/d.jpg">
              <div class="carousel-caption d-none d-md-block">
                  <h2>Selamat Datang,<?php echo $d['namalengkap']; ?> ! di Aplikasi Prakerin</h2>
                  <h2>Telkom Corporate University</h2>
                  <button class="btn btn-info" type="submit">Lihat Siswa</button>
              </div>
          </div>
          <div class="carousel-item">
            <img src="img/e.jpg" class="d-block w-100" alt="img/e.jpg">
              <div class="carousel-caption d-none d-md-block">
                  <h5>Second slide label</h5>
                  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
              </div>
          </div>
          <div class="carousel-item">
            <img src="img/f.jpg" class="d-block w-100" alt="img/f.jpg">
              <div class="carousel-caption d-none d-md-block">
                  <h5>Third slide label</h5>
                  <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
              </div>
          </div>
          <div class="carousel-item">
            <img src="img/g.jpg" class="d-block w-100" alt="img/g.jpg">
              <div class="carousel-caption d-none d-md-block">
                  <h5>Third slide label</h5>
                  <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
              </div>
          </div>
        </div>

        <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>
    </div>
    <div><hr><br><br  id="tentangkami-section"><br><br><br></div>
    <div class="text-center">
        <h2>Tentang Kami</h2>
        <p class="lead">This is a simple hero unit, a simple jumbotron-style component for calling extra attention to featured content or information.</p>
        <hr class="my-4">
        <p>It uses utility classes for typography and spacing to space content out within the larger container.</p>
        <p class="lead">
        <a class="btn btn-primary btn-lg" href="tentangkami.php" role="button">Lebih Lanjut...</a>
        </p>
    </div>
    <div><br><br><br><hr id="galeri-section"><br><br><br></div>
    <div class="text-center">
        <h2>Galeri</h2>
        <p class="lead">This is a simple hero unit, a simple jumbotron-style component for calling extra attention to featured content or information.</p>
        <hr class="my-4">
        <p>It uses utility classes for typography and spacing to space content out within the larger container.</p>
        <p class="lead">
        <a class="btn btn-primary btn-lg" href="galeri.php" role="button">Lebih Lanjut...</a>
        </p>
    </div>
    <div><br><br><br><hr id="kegiatan-section"><br><br><br></div>
    <div class="text-center">
        <h2>Kegiatan</h2>
        <p class="lead">This is a simple hero unit, a simple jumbotron-style component for calling extra attention to featured content or information.</p>
        <hr class="my-4">
        <p>It uses utility classes for typography and spacing to space content out within the larger container.</p>
        <p class="lead">
        <a class="btn btn-primary btn-lg" href="galeri.php" role="button">Lebih Lanjut...</a>
        </p>
    </div>
    <div><br><br><br><hr id="kontak-section"><br><br><br></div>
    <div class="text-center">
        <h2>Kontak</h2>
        <p class="lead">This is a simple hero unit, a simple jumbotron-style component for calling extra attention to featured content or information.</p>
        <hr class="my-4">
        <p>It uses utility classes for typography and spacing to space content out within the larger container.</p>
        <p class="lead">
        <a class="btn btn-primary btn-lg" href="galeri.php" role="button">Lebih Lanjut...</a>
        </p>
    </div>
    <div><br><br><br><hr></div>


    <footer class="page-footer font-small mdb-color bg-dark text-light lighten-3 pt-4">
      <div class="container text-center text-md-left bg-seconary">
        <div class="row">
          <div class="col-md-6 col-lg-5 mr-auto my-md-2 my-0 mt-5 mb-2">
            <img src="img/telkom.png" alt="img/telkom.png" width="400px">
          </div>
          <hr class="clearfix w-200 d-lg-none">
            <div class="col-md-6 col-lg-5 mx-auto my-md-4 my-0 mt-4 mb-1">
             <h5 class="font-weight-bold text-uppercase mb-4">Alamat</h5>
               <ul class="list-unstyled">
                <li><p><i class="fas fa-home mr-3"></i> Jalan Gegerkalong Hilir No. 47, Bandung, 40152</p></li>
                <li><p><i class="fas fa-envelope mr-3"></i> helpdesk.learning@telkom.co.id</p></li>
                <li><p><i class="fas fa-phone mr-3"></i> (+6222) 201-4508</p></li>
              </ul>
            </div>
          <hr class="clearfix w-100 d-md-none">
            <div class="col-md-2 col-lg-2 text-center mx-auto my-4">
              <!-- Social buttons -->
              <h5 class="font-weight-bold text-uppercase mb-4">Ikuti Kami</h5>
              <a type="button" class="btn-floating btn-fb">
                <i class="fab fa-facebook-f"></i>
              </a>
              <a type="button" class="btn-floating btn-tw">
                <i class="fab fa-twitter"></i>
              </a>
              <a type="button" class="btn-floating btn-gplus">
                <i class="fab fa-google-plus-g"></i>
              </a>
              <a type="button" class="btn-floating btn-dribbble">
                <i class="fab fa-dribbble"></i>
              </a>
            </div>
        </div>
      </div>
      <!-- Copyright -->
      <div class="footer-copyright text-center py-3"> © Copyright 2019: Telkom Corporate University  ||   Designed by
        <a href="https://www.instagram.com/alwary.a/"> Albi Alwary Gunawan</a> <a>&</a>
        <a href="https://www.instagram.com/putrialivvia23_/"> Putri Alivvia Maharani</a>
      </div> 
    </footer>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>