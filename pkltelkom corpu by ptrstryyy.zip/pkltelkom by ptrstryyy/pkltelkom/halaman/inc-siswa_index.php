<?php
/*
File: inc-buku.php
Fungsi: File untuk include halaman buku.
*/
//cek_user();

$key=mysql_real_escape_string($_GET['pencarian']);
$where=mysql_real_escape_string($_GET['where']);
$order=mysql_real_escape_string($_GET['order']);
$stat=mysql_real_escape_string($_GET['status']);
$bates=$_GET['banyak'];
putus();
if($where==''){
  $where='nama';  
}
if($order==''){
    $order='nama';
}
if($stat=='All'){
    $stat='%%';
}
if($stat==''){
    $stat='1';
}
if($bates==''){
    $bates='100';
}

//**Page**//
$bts= $bates;
$hal = $_GET['hal'];
if (!isset($hal)){
    $mulai=0;
}else{
    $mulai= $hal * $bts;
};
$a=mysql_query("SELECT * FROM tbl_siswa WHERE $where LIKE '%$key%' && status LIKE '$stat' ORDER BY $order ASC");
//Debug Program
//echo "SELECT * FROM tbl_buku WHERE $where LIKE '%$key%' && status LIKE '$stat' ORDER BY $order ASC";
$semua=mysql_query("SELECT * FROM tbl_siswa");
$semua=mysql_num_rows($semua);
$jumlah=mysql_num_rows($a);
$jhal=ceil($jumlah/$bts);

?>



<script type='text/javascript'>
  function kirim(){
    document.forms['frm-buku'].submit();
  }
</script>

<br><br>
<h2 class="text-center">Daftar Siswa Prakerin</h2>

<br><br>

<form id='cari' action='' method='GET' name='frm-buku'>
<table style='background-color: #99ccff;' width='100%' cellpadding='3' cellspacing='1' class="table table-striped table-hover">
    <tr>
       <td>
<a class=" btn-info fas fa-plus btn-lg" href="masukdong.php" role="button" aria-haspopup="true" aria-expanded="false" style="float: right"></a>
</td>

  <td>
      <select name='where' onchange='kirim()'>
    <option value='nama'>--Cari Berdasar--</option>
    <option value='nama' <?php if($_GET['where']=='nama'){ echo "selected='selected'";} ?>>Nama Lengkap</option>
    <option value='sekolah' <?php if($_GET['where']=='sekolah'){ echo "selected='selected'";} ?>>Asal Sekolah</option>
    <option value='nis' <?php if($_GET['where']=='nis'){ echo "selected='selected'";} ?>>NIS Sekolah</option>
    <option value='jurusan' <?php if($_GET['where']=='jurusan'){ echo "selected='selected'";} ?>>Jurusan</option>-->
    <option value='lokasipkl' <?php if($_GET['where']=='lokasipkl'){ echo "selected='selected'";} ?>>Lokasi Prakerin</option>
      </select>
  </td>
  
  </td>
  <td>
      <select name='order' onchange='kirim()' style="width: 150px;">
    <option value='nama'>--Urutkan--</option>
    <option value='nama' <?php if($_GET['where']=='nama'){ echo "selected='selected'";} ?>>Nama Lengkap</option>
    <option value='sekolah' <?php if($_GET['where']=='sekolah'){ echo "selected='selected'";} ?>>Asal Sekolah</option>
    <option value='nis' <?php if($_GET['where']=='nis'){ echo "selected='selected'";} ?>>NIS Sekolah</option>
    <option value='jurusan' <?php if($_GET['where']=='jurusan'){ echo "selected='selected'";} ?>>Jurusan</option>-->
    <option value='lokasipkl' <?php if($_GET['where']=='lokasipkl'){ echo "selected='selected'";} ?>>Lokasi Prakerin</option>
    <option value='no' <?php if($_GET['order']=='no'){ echo "selected='selected'";} ?>>Terbaru</option>
      </select>
  </td>
  <td>
     
  </td>
  <td>
      <select name='status' onchange='kirim()' style="width: 150px;">
        <option value='1'>--Status--</option>
        <option value='1'  <?php if($_GET['status']=='1'){ echo "selected='selected'";} ?>>Ada</option>
        <option value='0'  <?php if($_GET['status']=='0'){ echo "selected='selected'";} ?>>Di Pinjam</option>
        <option value='All'  <?php if($_GET['status']=='All'){ echo "selected='selected'";} ?>>Semua</option>
      </select>
  </td>
  <td>
      <select name='banyak' onchange='kirim()' style="width: 70px;">
    <option value='5'>--Banyak Data--</option>
    <option value='5'>5</option>
    <option value='15'>15</option>
    <option value='25' selected='selected'>25</option>
    <option value='30'>30</option>
    <option value='40'>40</option>
    <option value='60'>60</option>
                <option value='100'>100</option>
                <option value='200'>200</option>
                <option value='500'>500</option>
                <option value='1000'>1000</option>
      </select>
  </td>
  <td><input autocomplete='off' class="form-control" onchange='kirim()' class='cari' type='text' name='pencarian' value="<?php echo stripcslashes($key); ?>" placeholder="Cari" style="width: 200px; float: left" >
      <button class="btn btn-success" type="submit" data-toggle="tooltip" data-placement="top" title="Belum bisa Digunakan">Cari</button>

    </tr>
</table>
</form>

<div class="table-responsive">
  <table id='tbl_siswa' class="table table-hover table-light">
    <thead>
      <tr>
        <th scope="col">No.</th>
        <th scope="col">Nama</th>
        <th scope="col">Asal Sekolah</th>
        <th scope="col">NIS</th>
        <th scope="col">Jurusan</th>
        <th scope="col">Lokasi PKL</th>
        <th scope="col">Lainnya</th>
        <th scope="col"></th>
      </tr>
    </thead>
    <?php
sambung();
$a=mysql_query("SELECT * FROM tbl_siswa WHERE $where LIKE '%$key%' && status LIKE '$stat' ORDER BY $order ASC LIMIT $mulai, $bts");
//Debug Program
//echo "SELECT * FROM tbl_buku WHERE $where LIKE '%$key%' && status LIKE '$stat' ORDER BY $order ASC LIMIT $mulai, $bts";
$no=1;
$chek=mysql_num_rows($a);
if($chek==1){
  ?>
  <script type="text/javascript">
    $(document).ready(function(){
        $('#tmbl-pinjam').click();
    })
    
  </script>
  <?php
}
while ($m=mysql_fetch_array($a)){
    
    if($chek=='1' && $m['status'] != 'Kosong'){
    $judulku=addslashes($m['judul']);
    //echo "<script type='text/javascript'>
    //var jawaban = confirm( 'Pinjam Buku \"".$judulku."\" ?' );
    //if ( jawaban ){
    //window.open('pinjam.php?buku=".$m['no']."','popupwindow','scrollbars=yes, width=550,height=600, resizable=0, left = 462,top = 20, toolbar=no, menubar=no');
    //}   
    //</script>";
?>
<?php
}

    if($no % 2 == 0){
    $id='genap'; 
  }else{ 
    $id='ganjil'; 
    }
echo "<tr>";
    $script="window.open('pinjam.php?buku=".$m['no']."','popupwindow','scrollbars=yes, width=550,height=600, resizable=1, left = 462,top = 20');";
    echo "<td>".$no."</td>";
    
    echo "<td onclick='pokus".$m['no']."()' >".$m['nama']."</td>";
    
    echo "<td>".$m['sekolah']."</td>";
    
    echo "<td >".$m['nis']."</td>";

    echo "<td width='20'>".$m['jurusan']."</td>";
    
    echo "<td >".$m['lokasipkl']."</td>";
    
    echo "<td>";
    
   // if($m['status']=='Ada'){
     // echo "<a href='#' title='Lihat Detail' onclick=\"".$script."\"><img src='tampilan/gambar/centang.png' width='15' height='15'></a>";
    //}else{
      //echo "<a href='#' title='Sudah Dipinjam' onclick='alert(\"Tidak tersedia untuk di pinjam !\");'><img src='tampilan/gambar/no.png' width='15' height='15'></a>";
    //}
    
    //echo admin("<a href='buku.php?tambah=1&hapus=1&buku=".$m['kd_buku']."' title='Hapus Buku' onclick='return confirm(\"Yakin Hapus Buku Ini?\");'><img src='tampilan/gambar/ping.png' width='15' height='15'></a>");
    //echo admin("<a href='buku.php?tambah=1&tBuku=".$m['kd_buku']."' title='Tambah Buku Sejenis' onclick='return confirm(\"Tambah Buku?\");'><img src='tampilan/gambar/tambah.png' width='15' height='15'></a>");
    
    ?>
                <div class="btn-group">
        <?php if($m['status']=='1'){ ?>
                    <a id="tmbl-pinjam" class="btn btn-success tmbl-pinjam fa-cog" data-toggle="modal" href="ajax/ajax-pinjam.php?buku=<?php echo $m['nama'] ?>" data-target="#pop-pinjam"></a>

        <?php }else{ ?>
        <button class="btn btn-danger tmbl-pinjam" data-toggle="modal" data-target="#pop-nopinjam">Pinjam</button>
        <?php } ?>
                    <button class="btn dropdown-toggle btn-success" data-toggle="dropdown">
                      <span class="caret"></span>
                    </button>
                    <ul class="dropdown-menu">
                        <li><a href='buku.php?tambah=1&hapus=1&buku=<?php echo $m['nama'] ?>' title='Hapus Buku' onclick='return confirm("Yakin Hapus Buku Ini?");'>Hapus</a></li>
                        <li><a href='buku.php?tambah=1&tBuku=<?php echo $m["nama"]; ?>' title='Tambah Buku Sejenis' onclick='return confirm("Tambah Buku?");'>Tambah</a></li>
                    </ul>
              </div>
    <?php
    echo "</td>";
echo "</tr>";
?>
<?php
$no++;
}
if($chek=='0'){
    //echo "<script type='text/javascript'>alert('Data tidak ditemukan !')</script>";
    echo "<tr><td colspan='6' align='center' class='alert alert-error'><b>Data Tidak Ditemukan Silahkan Cek Kembali</b><br><i>Mungkin Buku Sudah di Pinjam, Periksa Kembali Kata Kunci Pencarian, Atau Atur Spesifikasi (Judul Buku / Kode Buku / Pengarang)</i></tr></td>";
}
echo "<tr><td colspan='5'>Menampilkan <b>".$chek."/".$jumlah."</b> Dari <b>".$semua."</b> Buku<td></tr>";

putus();
?>    
</table>
<?php
if ('1'=='1'){ ?>
    <ul class="pager">
      <li class="previous">
  <a style='text-decoration: none;' href='<?php echo "?where=$where&pencarian=$key&banyak=$bates&hal=".max($hal-1, 0); ?>'>&larr; Sebelumnya</a>
      </li>
      <li class="next">
  <a style='text-decoration: none;' href='<?php echo "?where=$where&pencarian=$key&banyak=$bates&hal=".min($hal+1, $jhal-1); ?>'>Selanjutnya &rarr;</a>
      </li>
    </ul>  
<?php } ?>
  </table>
</div>

