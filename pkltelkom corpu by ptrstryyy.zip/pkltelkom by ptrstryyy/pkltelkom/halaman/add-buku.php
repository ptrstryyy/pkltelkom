<?php
/*
Fungsi: File untuk inMenambahkan buku ke database.

*/


/*Jika Yang login adalah admin*/
if($_SESSION['level']=='Admin'){
    //**Sejenis**//
    $kbuk=$_POST['nama'];
    $sejenis=explode('/',$kbuk);
    //$not=$m['kd_buku'];
    $satu=$sejenis['0'];
    $dua=$sejenis['1'];
    $tiga=$sejenis['2'];
     
    $tiga=substr($tiga,0,2);
   
    $sejenis2= "$satu/$dua/$tiga";
    //echo $sejenis2;
    sambung();
    $sql=mysql_query("SELECT * FROM tbl_siswa WHERE nama LIKE '$sejenis2%' ORDER BY nama DESC");
    //$all=mysql_query("select * from buku where kd_buku like '$sejenis2%' && kd_buku not like '$not%'");
    $yang_sama=mysql_num_rows($sql);
    //$all=mysql_num_rows($all);
    if($yang_sama != '0' && $_GET['tBuku']==''/*&& !isset($_SESSION['tBuku'])*/){
        
        $has=mysql_fetch_array($sql);
        $urutan=substr($has['nama'],-3);
        echo "Ada Buku Yang Sekelompok dengan Kode <b>\"".$sejenis2."\"</b> Apakah Anda Ingin Melanjutkan?<br>";
        echo "<br><center><button onclick='direk();'>YA</button>  <button onclick='history.go(-1)'>TIDAK</button></center>";
        $hasil=$urutan+1;
        $urut_new= sprintf("%03s", $hasil);      
        echo "<script type='text/javascript'>function direk(){ window.location='siswa.php?tBuku=".$sejenis2."&tambah=1'; }</script>";
        exit();
    }
    
    
    //Jika Submit Tambah
    if($_POST['tambah'] && $_POST['nama']!=''){
        $nama=$_POST['nama'];
        $sekolah=mysql_real_escape_string($_POST['sekolah']);
        $nis=mysql_real_escape_string($_POST['nis']);
        $jurusan=$_POST['jurusan'];
        $lokasipkl=mysql_real_escape_string($_POST['lokasipkl']);
        $hrg=$_POST['harga'];
        sambung();
        $sql=mysql_query("INSERT INTO tbl_siswa SET nama='$nama', sekolah='$sekolah', nis='$nis', jurusan='$jurusan', lokasipkl='$lokasipkl', harga='$hrg', status='1'");
        //echo "INSERT INTO tbl_buku SET kd_buku='$kode', judul='$jdl', pengarang='$pngrng', thn_terbit='$thn', penerbit='$pnrbt', harga='$hrg'";
        if($sql){
            catat($_SESSION['nama'],"Menambah Siswa $nama($kode)");
            echo "<script type='text/javascript'>alert('Berhasil di Simpan');</script>";
        }else{
            catat($_SESSION['nama'],"Gagal Menambah Siswa $nama");
            echo "<script type='text/javascript'>alert('Gagal Di Simpan');</script>";
        }
    }
    //jika hapus
    if($_GET['hapus']=='1'){
        $bukune=$_GET['buku'];
        $guak=mysql_query("DELETE FROM tbl_siswa WHERE nama='$bukune'");
        if($guak){
            catat($_SESSION['nama'],"Menghapus Buku $bukune");
            //header('location: buku.php');
            echo "<script type=\"text/javascript\">window.location='siswa.php'</script>";
        }else{
            catat($_SESSION['nama'],"Gagal Menghapus Siswa $bukune");
            echo "<script type='text/javascript'>alert('Buku Gagal di Hapus \n Mohon di chek kembali.');</script>";
        }
    };
    if(isset($_GET['tBuku'])){
        $bukunya=$_GET['tBuku'];
            $by=explode('/',$bukunya);
                $kod=substr($by[2],0,2);
                    $bukunya=$by[0]."/".$by[1]."/".$kod;
                    //echo $bukunya;
        $sq=mysql_query("SELECT * FROM tbl_siswa WHERE nama LIKE '$bukunya%' ORDER BY nama DESC");
        $arr=mysql_fetch_array($sq);
        $scp=explode('/',$arr['nama']);
        $kd=substr($scp[2],0,2);
        $akhir= substr($scp[2],-3);
            $akhir=$akhir+1;
                $akhir=sprintf("%03s",$akhir);
        $valKB=$scp[0]."/".$scp[1]."/".$kd.$akhir;
        //echo $arr['kd_buku'];
        $_SESSION['tBuku']=$valKB;
    }
?>

<script type='text/javascript'>
  function kirim(){
    document.forms['frm-tambah'].submit();
  }
</script>
  <script type="text/javascript" ></script>
    <style type="text/css">
     
    #card{
        margin-left: 300px;
        width: 500px;
        border: 1px solid transparent;
        background-color: rgba(255,255,255);
        border-radius: 5px;
    }

    label{
        display: block;
    }

    input{
        width: 250px;
        background-color: #dcdcdc;
        border: 1px solid transparent;
        border-radius: 3px;
    }
    </style>
<br><br><br><br><br>

<div class="container">
    <div class="row no-gutter">
            <div class="login d-flex align-items-center py-5">
              <div class="container-center" id="card">
                <div class="row">
                  <div class="col-md-9 col-md-8 mx-auto" id="col1">
                    <br>
<h2 class="text-center text-dark">Tambah Data Siswa</h2>
<form action='' method='post' name='frm-tambah'>
<ul class="text-dark">
    <li style="list-style-type: none">
        <label>Nama Lengkap</label>
        <input type='text' name='nama' id='kb' value='<?php echo $valKB; ?>'>
    </li>
     <li style="list-style-type: none">
        <label>Asal Sekolah</label>
        <input class='input-xlarge' type='text' name='sekolah' value="<?php echo $arr['sekolah']; ?>">
    </li>
     <li style="list-style-type: none">
        <label>NIS</label>
        <input class='input-xlarge' type='text' name='nis' value="<?php echo $arr['nis']; ?>">
    </li>
    <li style="list-style-type: none">
        <label>Jurusan</label>
        <input  class='input-small' type='text' name='jurusan' value='<?php echo $arr['jurusan']; ?>'>
    </li>
    <li style="list-style-type: none">
        <label>Lokasi PKL</label>
        <input class='input-xlarge' type='text' name='lokasipkl' value="<?php echo $arr['lokasipkl']; ?>">
    </li>
    <li style="list-style-type: none">
        <label>Alamat </label>
        <input class='input-small' type='text' name='harga' value="<?php echo $arr['harga']; ?>">
    </li>
    <br>
    <li style="list-style-type: none">
        <button class="btn btn-lg bg-primary text-light" type='submit' value='Tambah' name='tambah'>Tambah</button>
    </li>
</ul>
</form>
</fieldset>
<?php }else{
    echo "<p class='alert alert-error'>Maaf, anda tidak memiliki akses ke halaman ini.</p>";
}?>

                  </div>
                </div>
              
            </div>
          </div>        
    </div>
  </div>
</div>
