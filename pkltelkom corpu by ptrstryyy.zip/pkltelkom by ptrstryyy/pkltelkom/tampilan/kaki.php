<?php
/*
File: kaki.php
Fungsi: Mengatur Tampilan bagian bawah
*/

?>

<footer class="page-footer text-white bg-dark font-small mdb-color lighten-3 pt-4">
      <div class="container text-center text-md-left bg-seconary">
        <div class="row">
          <div class="col-md-6 col-lg-5 mr-auto my-md-2 my-0 mt-5 mb-2">
            <img src="img/telkom.png" alt="img/telkom.png" width="400px">
          </div>
          <hr class="clearfix w-200 d-lg-none">
            <div class="col-md-6 col-lg-5 mx-auto my-md-4 my-0 mt-4 mb-1">
             <h5 class="font-weight-bold text-uppercase mb-4">Alamat</h5>
               <ul class="list-unstyled">
                <li><p><i class="fas fa-home mr-3"></i> Jalan Gegerkalong Hilir No. 47, Bandung, 40152</p></li>
                <li><p><i class="fas fa-envelope mr-3"></i> helpdesk.learning@telkom.co.id</p></li>
                <li><p><i class="fas fa-phone mr-3"></i> (+6222) 201-4508</p></li>
              </ul>
            </div>
          <hr class="clearfix w-100 d-md-none">
            <div class="col-md-2 col-lg-2 text-center mx-auto my-4">
              <!-- Social buttons -->
              <h5 class="font-weight-bold text-uppercase mb-4">Ikuti Kami</h5>
              <a type="button" class="btn-floating btn-fb">
                <i class="fab fa-facebook-f"></i>
              </a>
              <a type="button" class="btn-floating btn-tw">
                <i class="fab fa-twitter"></i>
              </a>
              <a type="button" class="btn-floating btn-gplus">
                <i class="fab fa-google-plus-g"></i>
              </a>
              <a type="button" class="btn-floating btn-dribbble">
                <i class="fab fa-dribbble"></i>
              </a>
            </div>
        </div>
      </div>
      <!-- Copyright -->
      <div class="footer-copyright text-center py-3"> © Copyright 2019: Telkom Corporate University  ||   Designed by
        <a href="https://www.instagram.com/alwary.a/"> Albi Alwary Gunawan</a> <a>&</a>
        <a href="https://www.instagram.com/putrialivvia23_/"> Putri Alivvia Maharani</a>
      </div> 
    </footer>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>