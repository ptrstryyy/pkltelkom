<?php
/*
File: kepala.php
Fungsi: Mengatur Tampilan bagian atas
Auth: ShowCheap
*/
//error_reporting(0);
cek_user();
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="shortcut icon" href="img/logo.png">
    <title>Telkom CorpU Prakerin</title>
  </head>


  <body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark text-white fixed-top">
    <div class="container">
      <a class="navbar-brand">
        <img src="img/logo.png" width="40" height="40" class="d-inline-block align-top" alt="img/logo.png"> Telkom CorpU Prakerin
      </a>    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">Beranda
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#tentangkami-section">Tentang Kami</a>
                <span class="sr-only">(current)</span>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Info</a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <a class="dropdown-item" href="siswa_index.php">Siswa Prakerin</a>
                  <a class="dropdown-item" href="masukdong.php">Pembimbing Siswa Prakerin</a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="#">Lainnya</a>
              </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Galeri</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Kegiatan</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Kontak</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle fas fa-search" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown"> 
                  <input type="text" class="form-control" name="query" placeholder="Kata Kunci" aria-label="search" style="width: 100px; float: left; border-radius:3px 0px 0px 3px;" >
                    <button class="btn btn-success" type="submit" data-toggle="tooltip" data-placement="top" title="Belum bisa Digunakan" style=" border-radius: 0px 3px 3px 0px;">Cari</button>
                  
              </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle fas fa-user" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="masuk.php">Masuk</a>
                <a class="dropdown-item" href="daftar.php">Daftar</a>
              </div>
          </li>
        </ul>
      </div>
    </div>
    </nav>
<div id='badan'>
