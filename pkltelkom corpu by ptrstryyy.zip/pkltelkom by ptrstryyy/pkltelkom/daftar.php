

  <!-- Menyisipkan Bootstrap -->
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="shortcut icon" href="logo.png">
      <title>Telkom CorpU Prakerin</title>

    <script type="text/javascript" ></script>
    <style type="text/css">
      body {
        background-color:black;
        background-image:url(img/c.jpg);
        background-size: cover;
        background-repeat: no-repeat;
      }

      #card{
        width: 1100px;
        height: 500px;
        display: inline-block;
        border: 1px solid transparent;
        background-color: rgba(255,255,255,.7);
        border-radius: 10px;

}
    </style>

<div class="container">
    <div class="row no-gutter">
            <div class="login d-flex align-items-center py-5">
              <div class="container-center" id="card">
                <div class="row">
                  <div class="col-md-9 col-md-8 mx-auto" id="col1">
                    <br>
                    <img src="logo.png" width="100" height="100"style="float:left" />
                    <h3 class="login-heading text-dark text-center">SELAMAT DATANG!!</h3>
                    <h3 class="text-dark text-center">DI APLIKASI DATA PRAKERIN</h3>
                    <h3 class="text-dark text-center">TELKOM CORPORATE UNIVERSITY</h3>
                      <br>

                      <h5>Silahkan Daftar Terlebih Dahulu</h5>

                      <a href="daftarkaryawan.php"><img src="img/l1.png" type="submit" src="img/l1.png" width="170" height="170" align="middle" style="margin-right: 140px;" /><a>

                      <a href="daftarsiswa.php"><img src="img/l2.png" type="submit" src="img/l2.png" width="170" height="170" ><a>

                      <a href="daftartamu.php"><img src="img/l3.png" type="submit" src="img/l3.png" width="170" height="170" align="middle" style="margin-left: 140px;" /><a>
                      <div class="text-center">
                        <br>
                        <a class="medium text-danger" href="login.php">Sudah Punya Akun??</a>
                        <br>
                        <a class="medium text-info" href="index.php">Kembali Ke Beranda..</a>
                      </div>
                  </div>
                </div>
              
            </div>
          </div>        
    </div>
  </div>
</div>
<script scr="js/bootstrap.min.js"></script>