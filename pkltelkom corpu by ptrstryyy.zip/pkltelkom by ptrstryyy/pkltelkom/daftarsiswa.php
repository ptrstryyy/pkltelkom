<?php 
	require 'sistem/config.php'

	if( isset($_POST["register"]) ){

		if( registrasi($_POST) > 0){
			echo "<script>
					alert('Sign Up Completed!');
				 </script>";
		} else {
			echo mysql_error(@sambung);
		}

	}
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Daftar Siswa Prakerin</title>

	<style>
		label{
			display: block;
		}
		
	</style>
</head>
<body>

	<h1>Silahkan Melakukan Registrasi!</h1>

		<form action="" method="post">
			
			<ul>

				<li>
					<label for="nis">NIS :</label>
					<input type="text" name="nis" id="nis">
				</li>
				<li>
					<label for="username">Username :</label>
					<input type="text" name="username" id="username">
				</li>
				<li>
					<label for="password">Password :</label>
					<input type="password" name="password" id="password">
				</li>
				<li>
					<label for="password2">Confirm Password :</label>
					<input type="password" name="password2" id="password2">
				</li>
				<li>
					<label for="school">Asal Sekolah :</label>
					<input type="text" name="school" id="school">
				</li>
				<br>
					<button type="submit" name="register">Register</button>
				
			</ul>
		</form>

</body>
</html>