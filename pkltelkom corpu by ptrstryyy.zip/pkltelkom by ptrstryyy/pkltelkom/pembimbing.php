  <div class="container">

    <div class="row">

      <div class="col" style="padding-top: 15px">
        <div class="card" style="width: 15rem; text-align: center;">
          <img class="card-img-top" src="img/l3.png" alt="Card image cap">
          <div class="card-body">
            <h5 class="card-title">Albi Alwary</h5>
            <p class="card-text">SMK KIAN SANTANG BDG</p>
            <a href="#" class="btn btn-primary">Selengkapnya!</a>
          </div>
        </div>
      </div>

      <div class="col" style="padding-top: 15px">
        <div class="card" style="width: 15rem; text-align: center;">
          <img class="card-img-top" src="img/l3.png" alt="Card image cap">
          <div class="card-body">
            <h5 class="card-title">Albi Alwary Gunawan</h5>
            <p class="card-text">SMK KIAN SANTANG BDG</p>
            <a href="#" class="btn btn-primary">Selengkapnya!</a>
          </div>
        </div>
      </div>

      <div class="col" style="padding-top: 15px">
        <div class="card" style="width: 15rem; text-align: center;">
          <img class="card-img-top" src="img/l3.png" alt="Card image cap">
          <div class="card-body">
            <h5 class="card-title">Albi Alwary Gunawan</h5>
            <p class="card-text">SMK KIAN SANTANG BDG</p>
            <a href="#" class="btn btn-primary">Selengkapnya!</a>
          </div>
        </div>
      </div>

      <div class="col" style="padding-top: 15px">
        <div class="card" style="width: 15rem; text-align: center;">
          <img class="card-img-top" src="img/l3.png" alt="Card image cap">
          <div class="card-body">
            <h5 class="card-title">Albi Alwary Gunawan</h5>
            <p class="card-text">SMK KIAN SANTANG BDG</p>
            <a href="#" class="btn btn-primary">Selengkapnya!</a>
          </div>
        </div>
      </div>

      <div class="col" style="padding-top: 15px">
        <div class="card" style="width: 15rem; text-align: center;">
          <img class="card-img-top" src="img/l3.png" alt="Card image cap">
          <div class="card-body">
            <h5 class="card-title">Albi Alwary Gunawan</h5>
            <p class="card-text">SMK KIAN SANTANG BDG</p>
            <a href="#" class="btn btn-primary">Selengkapnya!</a>
          </div>
        </div>
      </div>